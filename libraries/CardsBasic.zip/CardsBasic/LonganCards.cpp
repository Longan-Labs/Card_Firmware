// LONGAN CARDS

#include "LonganCards.h"
#include "cardBasic.h"

void CARD_INFO::setInfo(unsigned char __addr,   // I2C ADDR
                 int __sensorNo,                // SENSOR NUNBER
                 int __senCnt,                  // NUMBER OF SENSOR
                 int __nameLen,                 // LENGTH OF NAME
                 char __name[20],               // NAME OF SENSOR
                 long __sku,                    // SKU
                 float __version)               // VERSION
    {
        addr        = __addr;
        sensorNo    = __sensorNo;
        senCnt      = __senCnt;
        nameLen     = __nameLen;
        memcpy(name, __name, 20);
        sku         = __sku;
        version     = __version;
    }

void CARD_INFO::getInfo()
{
   
    //**************GET SENSOR NO.******************************************
    Wire.beginTransmission(addr); // transmit to device #8
    Wire.write(ADDR_SENSOR_NO);  
    Wire.endTransmission();    // stop transmitting
    delay(10);
    
    Wire.requestFrom(addr, 1);    // request 6 bytes from slave device #8
    delay(10);
    
    while (Wire.available())
    { // slave may send less than requested
        sensorNo = Wire.read();
    }
    delay(10);
    
    //**************GET SENSOR CNT******************************************
    Wire.beginTransmission(addr); // transmit to device #8
    Wire.write(ADDR_SNESOR_CNT);  
    Wire.endTransmission();    // stop transmitting
    delay(10);
    
    Wire.requestFrom(addr, 1);    // request 6 bytes from slave device #8
    delay(10);
    
    while (Wire.available())
    { // slave may send less than requested
        senCnt = Wire.read();
    }
    delay(10);
    
    //**************GET NAME LENGTH******************************************
    Wire.beginTransmission(addr); // transmit to device #8
    Wire.write(ADDR_NAME_LEN);  
    Wire.endTransmission();    // stop transmitting
    delay(10);
    
    Wire.requestFrom(addr, 1);    // request 6 bytes from slave device #8
    delay(10);
    
    while (Wire.available())
    { // slave may send less than requested
        nameLen = Wire.read();
    }
    delay(10);
    
    //**************GET NAME******************************************
    Wire.beginTransmission(addr); // transmit to device #8
    Wire.write(ADDR_GET_NAME);  
    Wire.endTransmission();    // stop transmitting
    delay(10);
    
    Wire.requestFrom(addr, nameLen);    // request 6 bytes from slave device #8
    delay(10);
    
    while (Wire.available())
    { // slave may send less than requested
        for(int i=0; i<nameLen; i++)
        {
            name[i] = Wire.read();
        }
        name[nameLen] = '\0';
    }
    delay(10);
    
    //**************GET SKU******************************************
    Wire.beginTransmission(addr); // transmit to device #8
    Wire.write(ADDR_GET_SKU);  
    Wire.endTransmission();    // stop transmitting
    delay(10);
    
    Wire.requestFrom(addr, 4);    // request 6 bytes from slave device #8
    delay(10);
    
    unsigned char tmp[4];
    unsigned char tmplen = 0;
    
    while (Wire.available())
    { // slave may send less than requested
        
        tmp[tmplen++] = Wire.read();
    }
    
    if(tmplen == 4)
    {
        sku = str2float(tmp);
    }
    else
    {
        sku = 0;
    }
    delay(10);
    
    
    //**************GET VERSION******************************************
    Wire.beginTransmission(addr); // transmit to device #8
    Wire.write(ADDR_GET_VER);  
    Wire.endTransmission();    // stop transmitting
    delay(10);
    
    Wire.requestFrom(addr, 4);    // request 6 bytes from slave device #8
    delay(10);
    
    tmplen = 0;
    while (Wire.available())
    { // slave may send less than requested
        
        tmp[tmplen++] = Wire.read();
    }
    
    if(tmplen == 4)
    {
        version = str2float(tmp);
    }
    else
    {
        version = 0;
    }
    delay(10);
}

void CARD_INFO::disp()
{
    /*    
    unsigned char addr;
    unsigned char sensorNo;
    unsigned char senCnt;
    unsigned char nameLen;
    char name[20];
    long sku;
    float version;
    */
    
    Serial.print("ADDR: 0x");
    if(addr < 0x10)Serial.print('0');
    Serial.println(addr, HEX);
    
    Serial.print("SENSOR NO.");
    Serial.println(sensorNo);
    
    Serial.print("SENSOR CNT: ");
    Serial.println(senCnt);
    
    Serial.print("NAME LEN: ");
    Serial.println(nameLen);
    
    Serial.print("NAME: ");
    Serial.println(name);
    
    Serial.print("SKU: ");
    Serial.println((long)sku);
    
    Serial.print("VERSION: ");
    Serial.println(version, 2);
}
/*
float CARD_INFO::str2float(unsigned char *str)
{
    float num = 0;
    memcpy((unsigned char *)(&num), str, 4);
    return num;
}*/

// END FILE