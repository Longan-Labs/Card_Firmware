#include "cardBasic.h"
#include "LonganCards.h"
#include "CardsDfs.h"

unsigned char dtaCnt = 0;       // count of sensor

int blinkCnt = 0;
CARD_INFO cardInfo;

unsigned char i2cDtaRaw[20];
unsigned char i2cDtaLen = 0;

float valueSensor[10];          // 10 value most
unsigned char dtaType[10];
unsigned char dtaUnit[10];

void cardInit()
{
    pinMode(3, OUTPUT);
    
    Wire.begin(cardInfo.addr);              // join i2c bus with address #8
    Wire.onReceive(receiveEvent);           // register event
    Wire.onRequest(requestEvent);           // register event
}

void blinkStart()
{
    blinkCnt = 10;
}

void blinkProcess()
{
    if(blinkCnt == 0)return;
    
    static unsigned long timer_s = millis();
    if(millis()-timer_s < 5)return;
    timer_s = millis();
    
    if(blinkCnt == 10)digitalWrite(3, HIGH);
    
    blinkCnt--;
    
    if(blinkCnt == 0)digitalWrite(3, LOW);
}


// get data from master
void receiveEvent(int howMany)
{
    blinkStart();
    while(Wire.available()>0)
    {
        i2cDtaRaw[i2cDtaLen++] = Wire.read();
    }
}


void requestEvent()
{
    requestFun();
}


void requestFun()
{
    blinkStart();

    if(i2cDtaLen == 1)
    {

        i2cDtaLen = 0;
        
        if(i2cDtaRaw[0] < ADDR_DATA_START)     // get info
        {
            switch(i2cDtaRaw[0])
            {
                case ADDR_SENSOR_NO:
                //Serial.println(cardInfo.sensorNo, HEX);
                Wire.write(cardInfo.sensorNo);
                break;
                
                case ADDR_SNESOR_CNT:
                Wire.write(cardInfo.senCnt);
                break;
                
                case ADDR_NAME_LEN:
                Wire.write(cardInfo.nameLen);
                break;
                
                case ADDR_I2C_ADDR:
                Wire.write(cardInfo.addr);
                break;
                
                case ADDR_GET_NAME:
                
                for(int i=0; i<cardInfo.nameLen; i++)
                    Wire.write(cardInfo.name[i]);
                
                break;
                
                case ADDR_GET_SKU:
                    {
                        char str[4];
                        float2str(cardInfo.sku, str);
                        for(int i=0; i<4; i++)
                            Wire.write(str[i]);
                    }
                
                break;
                
                case ADDR_GET_VER:
                    {
                        char str[4];
                        float2str(cardInfo.version, str);
                        for(int i=0; i<4; i++)
                            Wire.write(str[i]);
                    }
                
                break;
                
                default:
                break;
            }
        }
        else        // get sensor value
        {
            unsigned char valueN = i2cDtaRaw[0] - ADDR_DATA_START;
            
            unsigned char rt[6];
            memset(rt, 0, 6);

            rt[0] = dtaType[valueN];
            float2str((float)valueSensor[valueN], &rt[1]);
            rt[5] = dtaUnit[valueN];
            for(int i=0; i<6; i++)
            {
                Wire.write(rt[i]);
            }

        }
    }
}

void float2str(float num, unsigned char *str)
{
    memcpy(str, (unsigned char*)(&num), 4);
}

float str2float(unsigned char *str)
{
    float num = 0;
    memcpy((unsigned char *)(&num), str, 4);
    return num;
}